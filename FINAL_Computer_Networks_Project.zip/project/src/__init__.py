"""QoS routing laboratory simulation."""
